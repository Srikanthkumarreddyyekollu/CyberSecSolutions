# UnsignTool
UnsignTool using ImageRemoveCertificate

https://en.wikipedia.org/wiki/Portable_Executable

Normally, files signed with a signature can't have those signatures removed unless they are rebuilt.  This tool shows how to remove such a signature from any binary (PE).  This can come in handy during developement though rebuilding and resigning is usually part of the project.  

Usage: UnsignTool <filename to unsign>
