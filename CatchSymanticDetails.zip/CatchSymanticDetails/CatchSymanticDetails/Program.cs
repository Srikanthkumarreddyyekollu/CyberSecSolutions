﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Permissions;
using Microsoft.Win32;
using System.IO;
using System.Net;


namespace CatchSymanticDetails
{
    public class Program
    {
   
    }
}
