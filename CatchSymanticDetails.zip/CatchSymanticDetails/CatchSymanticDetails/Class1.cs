﻿using System;
using System.IO;
using Microsoft.Win32;
using System.Data;
using System.Data.OleDb;
using System.Net.NetworkInformation;
using System.Security.Permissions;

namespace CatchSymanticDetails
{
    class Class1
    {
        public static void Main(string[] args)
        {
            string NAVDefKey;
            Class1 obj = new Class1();
            DataSet ds = new DataSet();
            ds = obj.ReadExcel();
            byte[] data;
            string s = "";
            try
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    s += "<html><table border='2'><tr style='background-color:#2C8126;color:white;font-family:Calibri;'>";
                    s += "<th>" + "Machine Name" + "</th>" + "<th>" + "Def Date" + "</th>" + "<th>" + "Remote Desktop Check" + "</th>" + "<th>" + "USB Check " + "</th>" + "<th>" + "Shared Folders" + "</th>";
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string remotename = ds.Tables[0].Rows[i]["MACHINE"].ToString().Trim();
                        //obj.FetchSymanticDetails(remotename, out SymanticDefKey);
                        s += "<tr style='font-family:Calibri;font-size:14px;'>";
                        //s += "<td>" + remotename + "</td>" + "<td>" + NAVDefKey + "</td>" + "</tr>";
                    }
                    s += "</table></html>";
                    data = System.Text.Encoding.ASCII.GetBytes(s);
                    System.IO.MemoryStream ms = new System.IO.MemoryStream(data);
                    string path = "OutPutExcel.xls";
                    FileStream file;
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                        file = new FileStream("OutPutExcel.xls", FileMode.Create, FileAccess.Write);
                    }
                    else
                    {
                        file = new FileStream("OutPutExcel.xls", FileMode.Create, FileAccess.Write);
                    }
                    ms.WriteTo(file);
                    file.Close();
                    ms.Close();
                }
            }
            catch (Exception ex)
            {
                return;
            }
        }

        public DataSet ReadExcel()
        {
            string filename = Path.GetFileName("InputExcel.xlsx");// to get filename            
            string path = "InputExcel.xlsx";
            string conStr = string.Empty;
            string extension = Path.GetExtension(filename);//to get extension name of the file
            string ConStr = "";
            if (extension.Trim() == ".xls")
            {
                ConStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"";
            }
            else if (extension.Trim() == ".xlsx")
            {
                ConStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=2\"";
            }
            string query = "SELECT * FROM [Sheet4$]";//Select sheet
            OleDbConnection conn = new OleDbConnection(ConStr);
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            OleDbCommand cmd = new OleDbCommand(query, conn);
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            return ds;
        }

        public void FetchSymanticDetails(string rname, out string Symantic)
        {
            RegistryKey SymanticDefKey;
            string value = string.Empty;
            string remoteName = rname;
            try
            {
                string host = rname;
                Ping p = new Ping();
                PingReply reply = p.Send(host, 1000);
                if (reply.Status == IPStatus.Success)
                {
                    //---------------------------------------
                    // Check Symantec Virus Def Date
                    SymanticDefKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, remoteName).OpenSubKey("Software\\Symantec\\Symantec Endpoint Protection\\CurrentVersion\\public-opstate");
                    if (SymanticDefKey != null)
                    {
                        object o = SymanticDefKey.GetValue("LatestVirusDefsDate");
                        if (o != null)
                        {
                            Symantic = o as string;
                        }
                        else
                            Symantic = "";
                    }
                    else
                        Symantic = "Not Found";
                    // Close the registry key.
                    SymanticDefKey.Close();
                    //---------------------------------------                    
                }
                else
                {
                    Symantic = "Machine name not available!";
                }
            }
            catch
            {
                Symantic = "Machine name not available!";
            }
        }
    }
}       
    

