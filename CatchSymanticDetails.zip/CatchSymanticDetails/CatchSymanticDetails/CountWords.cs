﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CatchSymanticDetails
{
    class CountWords
    {
        public static void Main()
        {
            CountWords obj = new CountWords();
            Console.WriteLine("Enter the sentence and it will return number of words in it.");
            string word = Console.ReadLine();
            Console.WriteLine("Number of words:" + obj.WordCount(word));
            int number=0;
            int letter = 0;
            int specialcharater = 0;
            obj.CharacterCount(word, out number, out letter, out specialcharater);
            Console.WriteLine("Number of Numbers:" + number);
            Console.WriteLine("Number of Letter:" + letter);
            Console.WriteLine("Number of Special Charaters:" + specialcharater);
            Console.ReadLine();
        }

        public int WordCount(string w)
        {
            string s = w;
            int c=1;
            for(int i=0;i<s.Length;i++)
            {
                if(char.IsWhiteSpace(s[i])==true)
                {
                    c++;
                }
            }
            return c;
        }

         public void CharacterCount(string w,out int dig,out int let,out int sp)
        {
            char[] word = w.ToCharArray();
            dig = 0;
            let = 0;
            sp = 0;
            for(int i=0;i<word.Length;i++)
            {
                if (char.IsDigit(word[i]) == true)
                {
                    dig++;
                }
                else if (char.IsLetter(word[i]) == true)
                {
                    let++;
                }
                else
                    sp++;
            }
        }
    }
}
